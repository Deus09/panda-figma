/// <reference types="vite/client" />

declare module '*.svg' {
  const content: string;
  export default content;
}

declare module '*.png' {
  const content: string;
  export default content;
}

declare module '*.jpg' {
  const content: string;
  export default content;
}

declare module '*.jpeg' {
  const content: string;
  export default content;
}

// NodeJS namespace için timer türleri
declare namespace NodeJS {
  interface Timeout {
    readonly [Symbol.toPrimitive]: () => number;
  }
}
